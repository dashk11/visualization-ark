




// Parse the date / time
let parseTime = d3.timeParse("%a, %d %b %Y %H:%M:%S GMT");
let formatDate = d3.timeFormat("%Y-%m-%d %H:%M:%S");


let parseTime2 = d3.timeParse("%Y-%m-%d %H:%M:%S.%L");
let parseTime3 = d3.timeParse("%Y-%m-%d %H:%M:%S");

let selectedDataAggregationInput = "daily"

let filters = {
    startTime: parseTime2("2023-04-19 05:05:03.964"),
    endTime: parseTime2("2023-04-19 05:59:59.313"),
    data: {
        "daily": {temperature: temperatureData, pH: pHData, oxygen: oxygenData, pressure: pressureData },
        "15min": {temperature: temperatureData15Min, pH: pHData15Min, oxygen: oxygenData15Min, pressure: pressureData15Min },
        "30min": {temperature: temperatureData30Min, pH: pHData30Min, oxygen: oxygenData30Min, pressure: pressureData30Min },
    }
}

drawAggregateChart();

plotSubGraphs();


function plotSubGraphs() {
    let dataAggregationInput = document.getElementById("seedSelect");
    selectedDataAggregationInput = String(dataAggregationInput.selectedOptions[0].value)

    drawTemperatureChart();
    drawPHChart();
    drawOxygenChart();
    drawPressureChart();
}



function standardizeTimeSeriesData(data, applyFilter=false) {
    data = data.map(function (d) {
        let dt = parseTime(d[0])
        let val = +d[1];
        if (applyFilter) {
            if ((filters.startTime <= dt) && (dt <= filters.endTime)) {
                return { date: dt, value: val };
            }  
        } else {
            return {date: dt, value: val};
        }
        
    });
    data = data.filter(item => item !== undefined);
    return data
}

function drawAggregateChart() {
    let multilineSvg = d3.select("#multilineSvg")
    normalizedTemperatureData = standardizeTimeSeriesData(normalizedTemperatureData);
    normalizedPHData = standardizeTimeSeriesData(normalizedPHData);
    normalizedOxygenData = standardizeTimeSeriesData(normalizedOxygenData);
    normalizedPressureData = standardizeTimeSeriesData(normalizedPressureData);

    drawMultiLineChart(normalizedTemperatureData, normalizedPHData, normalizedOxygenData, normalizedPressureData, multilineSvg)
}   


function drawTemperatureChart() {
    let temperatureDataSvg = d3.select("#temperatureDataSvg");
    transformedData = standardizeTimeSeriesData(filters.data[selectedDataAggregationInput].temperature, true);
    console.log("temp", transformedData)
    drawLineChart(transformedData, temperatureDataSvg)
}
function drawPHChart() {
    let pHDataSvg = d3.select("#pHDataSvg");
    transformedData = standardizeTimeSeriesData(filters.data[selectedDataAggregationInput].pH, true);
    drawLineChart(transformedData, pHDataSvg)
}
function drawOxygenChart() {
    let oxygenDataSvg = d3.select("#oxygenDataSvg");
    transformedData = standardizeTimeSeriesData(filters.data[selectedDataAggregationInput].oxygen, true);
    drawLineChart(transformedData, oxygenDataSvg)
}
function drawPressureChart() {
    let pressureDataSvg = d3.select("#pressureDataSvg");
    transformedData = standardizeTimeSeriesData(filters.data[selectedDataAggregationInput].pressure, true);
    drawLineChart(transformedData, pressureDataSvg)
}


function drawLineChart(transformedData, svg) {
    svg.selectAll("g").remove()
    // Set the dimensions and margins of the graph
    let margin = { top: 20, right: 20, bottom: 30, left: 0 },

    width = svg.style('width').replace('px','')-100;
    height = svg.style('height').replace('px', '')-70;
    
    
    let x = d3.scaleTime()
        .domain(d3.extent(transformedData, function(d) { return d.date; }))
        .range([ 0, width ]);
    let y = d3.scaleLinear()
        .domain([d3.min(transformedData, function(d) { return +d.value; }), d3.max(transformedData, function(d) { return +d.value; })])
        .range([height, 0]);
    
    svg.append("g")
        // .transition()
        .attr("transform", `translate(${margin.left},${height})`)
        .call(d3.axisBottom(x));

    svg.append("g")
        // .transition()
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(y));

    // Add the line
    svg
        .selectAll(".line")
        .data([transformedData])
        .join("path")
        .transition()
        .attr("class", "line")
        .attr("fill", "none")
        .attr("stroke", "steelblue")
        .attr("stroke-width", 1)
        .attr("d", d3.line()
        .x(function(d) { return margin.left+x(d.date) })
        .y(function(d) { return y(d.value) })
    )  
}

// multilineSvg
function drawMultiLineChart(data1, data2, data3, data4, svg) {
    // Set the dimensions and margins of the graph
    let margin = { top: 20, right: 20, bottom: 30, left: 0 },

    width = svg.style('width').replace('px','')-100;
    height = svg.style('height').replace('px', '')-70;
    
    
    let x = d3.scaleTime()
        .domain(d3.extent(data1, function(d) { return d.date; }))
        .range([ 0, width+margin.left ]);
    let y = d3.scaleLinear()
        .domain([0, 1])
        .range([height, 0]);
    
    svg.append("g")
        .attr("transform", `translate(${margin.left},${height})`)
        .call(d3.axisBottom(x));

    svg.append("g")
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(y));

    let paddingLeft = 2;

    svg.append("path")
        .datum(data1)
        .attr("fill", "none")
        .attr("stroke", "purple")
        .attr("stroke-width", 1)
        .attr("d", d3.line()
        .x(function(d) { return paddingLeft+margin.left+x(d.date) })
        .y(function(d) { return y(d.value) })
    )  
    svg.append("path")
        .datum(data2)
        .attr("fill", "none")
        .attr("stroke", "green")
        .attr("stroke-width", 1)
        .attr("d", d3.line()
        .x(function(d) { return paddingLeft+margin.left+x(d.date) })
        .y(function(d) { return y(d.value) })
    )  
    svg.append("path")
        .datum(data3)
        .attr("fill", "none")
        .attr("stroke", "blue")
        .attr("stroke-width", 1)
        .attr("d", d3.line()
        .x(function(d) { return paddingLeft+margin.left+x(d.date) })
        .y(function(d) { return y(d.value) })
    )  
    svg.append("path")
        .datum(data4)
        .attr("fill", "none")
        .attr("stroke", "red")
        .attr("stroke-width", 1)
        .attr("d", d3.line()
        .x(function(d) { return paddingLeft+margin.left+x(d.date) })
        .y(function(d) { return y(d.value) })
    )  



    // Brush setup
    let brush = d3.brushX()
        .extent([[margin.left, 0], [width, height]])
        .on("end", brushEnded);

    // Append brush to the SVG
    let brushG = svg.append("g")
       .attr("class", "brush")
       .call(brush);

    // Set the initial brush selection to cover the full width and height
    brushG.call(brush.move, [margin.left, width+margin.left]);

    function brushEnded(event) {
        if (!event.selection) {
            return;
        }

        // Get the selected range in terms of pixels
        let [x0, x1] = event.selection;

        // Convert pixel values back to dates
        let selectedStartDate = x.invert(x0);
        let selectedEndDate = x.invert(x1);

        // Log the selected date range

        console.log("Selected start date:", parseTime3(formatDate(selectedStartDate)));
        console.log("Selected end date:", parseTime3(formatDate(selectedEndDate)));
        filters.startTime = parseTime3(formatDate(selectedStartDate))
        filters.endTime = parseTime3(formatDate(selectedEndDate))
        plotSubGraphs();
    }
    
}

